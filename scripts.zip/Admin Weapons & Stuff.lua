getglobal game
getfield -1 ReplicatedStorage
getfield -1 Weapons
getfield -1 Primary
getfield -1 ShockRifle
getglobal game
getfield -1 ReplicatedStorage
getfield -1 Remotes
getfield -1 StoreEquip
getfield -1 InvokeServer
pushvalue -2
pushstring Primary
pushvalue -8
pcall 3 0 0
emptystack
getglobal game
getfield -1 ReplicatedStorage
getfield -1 Weapons
getfield -1 Secondary
getfield -1 BeaconStudioSword
getglobal game
getfield -1 ReplicatedStorage
getfield -1 Remotes
getfield -1 StoreEquip
getfield -1 InvokeServer
pushvalue -2
pushstring Secondary
pushvalue -8
pcall 3 0 0
emptystack
getglobal game
getfield -1 ReplicatedStorage
getfield -1 Weapons
getfield -1 Special
getfield -1 BanHammer
getglobal game
getfield -1 ReplicatedStorage
getfield -1 Remotes
getfield -1 StoreEquip
getfield -1 InvokeServer
pushvalue -2
pushstring Secondary
pushvalue -8
pcall 3 0 0
emptystack