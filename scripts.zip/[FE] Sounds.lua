while true do
game.SoundService.Boing.Playing = true
wait(0.1)
game.SoundService.Bomb.Playing = true
wait(0.1)
game.SoundService.Break.Playing = true
wait(0.1)
game.SoundService.Click.Playing = true
wait(0.1)
game.SoundService.Clock.Playing = true
wait(0.1)
game.SoundService.Page.Playing = true
wait(0.1)
game.SoundService.Ping.Playing = true
wait(0.1)
game.SoundService.Slingshot.Playing = true
wait(0.1)
game.SoundService.Snap.Playing = true
wait(0.1)
game.SoundService.Splat.Playing = true
wait(0.1)
game.SoundService.Step.Playing = true
wait(0.1)
game.SoundService.StepOn.Playing = true
wait(0.1)
game.SoundService.Swoosh.Playing = true
wait(0.1)
end