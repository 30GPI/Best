game.Workspace.Events.GamePasses.EquipScubaGear:FireServer()
game.Workspace.Events.GamePasses.EquipFlareGun:FireServer()