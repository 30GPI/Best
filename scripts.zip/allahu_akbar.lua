-- made by exploit busters|kicks
local aa = Instance.new("Sound", game.workspace)
aa.SoundId = "rbxassetid://396873260"
aa.PlaybackSpeed = 0.25
aa.Name = "allahu akbar"
aa.Looped = true
aa:Play()