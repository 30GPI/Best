game.Lighting["LinkedSword3"]:Clone().Parent = game.Players.LocalPlayer.Backpack
game.Lighting["LinkedSword2"]:Clone().Parent = game.Players.LocalPlayer.Backpack
game.Lighting["LinkedSword"]:Clone().Parent = game.Players.LocalPlayer.Backpack