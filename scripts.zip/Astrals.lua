getglobal game
getfield -1 ReplicatedStorage
getfield -1 Remote
getfield -1 Event
getfield -1 FireServer
pushvalue -2
pushstring giveastrals
pushnumber 475474567
pcall 3 1 0