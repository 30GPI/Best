getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring spacesandwich
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring bloxycola
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring pizza
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring turkeyleg
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring watermelon
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring foamfinger
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring taco
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring icecream
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring teddybloxpin
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring fortunecookie
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring noobsign
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring bang
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring fakec4
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring witchesbrew
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring misfortunecookie
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring mummyteddy
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring fireflyjar
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring poolnoodle
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring fireextinguisher
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring dancepotion
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring confetticannon
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring moneybag
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring spork
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipGear
pushstring mackerel
pcall 3 1 0