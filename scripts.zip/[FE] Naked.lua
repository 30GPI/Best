game.Players.LocalPlayer.Character.Shirt:Remove()
game.Players.LocalPlayer.Character.Pants:Remove()