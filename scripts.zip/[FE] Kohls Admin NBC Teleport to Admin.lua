--Scripted by Bloxy

--Kohls Admin House NBC Admin Script



now = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame

game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame

=

game.Workspace.Terrain.GameFolder.Admin.Pads['Touch to get admin'].Head.CFrame

wait(0.2)

game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = now