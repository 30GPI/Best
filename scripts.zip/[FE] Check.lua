if game.Workspace.FilteringEnabled == false then
print("Filtering is disabled!")
end
if game.Workspace.FilteringEnabled == true then
print("Filtering is enabled!")
end