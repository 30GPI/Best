getglobal game
getfield -1 ReplicatedStorage
getfield -1 Tutorials
getfield -1 free_simcard
getfield -1 InvokeServer
pushvalue -2
pcall 1 0 0
emptystack