while true do
game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 100
wait()
end