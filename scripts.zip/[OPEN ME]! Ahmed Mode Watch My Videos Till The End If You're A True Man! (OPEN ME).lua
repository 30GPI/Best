┏━━━┳┓╋╋╋╋╋╋╋╋╋┏┓┏━┓┏━┓╋╋╋╋┏┓
┃┏━┓┃┃╋╋╋╋╋╋╋╋╋┃┃┃┃┗┛┃┃╋╋╋╋┃┃
┃┃╋┃┃┗━┳┓┏┳━━┳━┛┃┃┏┓┏┓┣━━┳━┛┣━━┓
┃┗━┛┃┏┓┃┗┛┃┃━┫┏┓┃┃┃┃┃┃┃┏┓┃┏┓┃┃━┫
┃┏━┓┃┃┃┃┃┃┃┃━┫┗┛┃┃┃┃┃┃┃┗┛┃┗┛┃┃━┫
┗┛╋┗┻┛┗┻┻┻┻━━┻━━┛┗┛┗┛┗┻━━┻━━┻━━┛
Ahmed Mode
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
if you really really want to support me

subscribe like and share
and watch my videos till the end even skip the ads so i can even get paid from youtube

and yeah thanks for being a nice true fan

my channel link to support it

Ahmed Mode

Link https://www.YouTube.com/AhmedMode

hope you enjoyed i only make this videos for you! :D <3


bye ^^