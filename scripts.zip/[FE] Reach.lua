a=Instance.new("SelectionBox",game.Players.LocalPlayer.Backpack.Foil.Handle)
a.Adornee=game.Players.LocalPlayer.Backpack.Foil.Handle
game.Players.LocalPlayer.Backpack.Foil.Handle.Size=Vector3.new(1,1,30)