while true do
game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 25
wait()
game.Players.LocalPlayer.Character.Humanoid.Sit       = true
wait()
game.Players.LocalPlayer.Character.Humanoid.Jump = true
wait()
end