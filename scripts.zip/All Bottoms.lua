getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring gearbottom
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring whirlwindbottom
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring loadingbottom
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring chakrabottom
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring magiccirclebottom
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring pantsonfirebottom
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring epicfacebottom
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring clockworkbottom
pcall 3 1 0

getglobal game
getfield -1 ReplicatedStorage
getfield -1 Inventory
getfield -1 FireServer
pushvalue -2
pushstring EquipAura
pushstring dancefloorbottom
pcall 3 1 0