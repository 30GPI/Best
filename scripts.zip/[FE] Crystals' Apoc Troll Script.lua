 for i,v in pairs(game.Players:GetChildren()) do game.Lighting.Remote.SendMessage:FireServer(v, 'Green', "Apocalypse Rising 2 BETA has been released!") end 

--change 'Green' to 'Yellow' , 'Red' , or 'Blue' for different colors
