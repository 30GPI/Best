_G.InstantTeleport = true
spawn(loadstring(game:HttpGet("https://pastebin.com/raw/z764JAEG", true)))()