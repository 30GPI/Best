while wait(0.5) do
game.ReplicatedStorage.rE.AddEffects:FireServer(Workspace.CarCollection.urnameherelol.Car.Body.HitBoxes.Front, 2305, 213)
game.ReplicatedStorage.rE.AddEffects:FireServer(Workspace.CarCollection.urnameherelol.Car.Body.HitBoxes.Back, 2305, 213)
game.ReplicatedStorage.rE.AddEffects:FireServer(Workspace.CarCollection.urnameherelol.Car.Body.HitBoxes.Roof, 2305, 213)
end