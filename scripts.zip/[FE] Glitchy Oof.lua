while true do
    game.Players.LocalPlayer.Character.Head.Died.Playing = true
wait()
game.Players.LocalPlayer.Character.Head.Died.Playing = false
wait()
end